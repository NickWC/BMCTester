
def convertFILETIMEtoEpoch(t):
    return (t - 116444736000000000L) / 10000000.0;
